package bombermanmapgenerator;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class BombermanMapGenerator {

    public static void main(String[] args) {
        BufferedImage img = null;
        BufferedWriter writer = null;
        File arqImg = null;
        File arqSaida = null;
        try {
            final JFileChooser fc = new JFileChooser();
            fc.setDialogType(JFileChooser.OPEN_DIALOG);
            fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
            FileNameExtensionFilter filter = new FileNameExtensionFilter("Imagem PNG", "png");
            fc.setFileFilter(filter);
            fc.setDialogTitle("Abrir arquivo de imagem do mapa");
            int returnVal = fc.showOpenDialog(null);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                arqImg = fc.getSelectedFile();
                System.out.println("Selecionado arquivo de entrada: " + arqImg.getName());
            } else {
                throw new Exception("É necessário especificar uma imagem de entrada!");
            }
            if (!arqImg.exists()) {
                throw new Exception("O arquivo selecionado não existe");
            }

            final JFileChooser fc2 = new JFileChooser() {
                @Override
                public void approveSelection() {
                    File f = getSelectedFile();
                    if (f.exists() && getDialogType() == SAVE_DIALOG) {
                        int result = JOptionPane.showConfirmDialog(this, "O arquivo já existe, sobrescrever?", "Arquivo existente", JOptionPane.YES_NO_CANCEL_OPTION);
                        switch (result) {
                            case JOptionPane.YES_OPTION:
                                super.approveSelection();
                                return;
                            case JOptionPane.NO_OPTION:
                                return;
                            case JOptionPane.CLOSED_OPTION:
                                return;
                            case JOptionPane.CANCEL_OPTION:
                                cancelSelection();
                                return;
                        }
                    }
                    super.approveSelection();
                }
            };
            fc2.setAcceptAllFileFilterUsed(true);
            fc2.setDialogType(JFileChooser.SAVE_DIALOG);
            fc2.setFileSelectionMode(JFileChooser.FILES_ONLY);
            filter = new FileNameExtensionFilter("Javascript", "js");
            fc2.setFileFilter(filter);
            fc2.setDialogTitle("Salvar arquivo Javascript do mapa");
            fc2.setFileHidingEnabled(false);
            returnVal = fc2.showSaveDialog(null);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                arqSaida = fc2.getSelectedFile();
                System.out.println("Selecionado arquivo de saída: " + arqSaida.getName());
            } else {
                throw new Exception("É necessário especificar um arquivo de saída!");
            }

            writer = new BufferedWriter(new FileWriter(arqSaida));
            writer.write("var mapaMascara = [\n");
            img = ImageIO.read(arqImg);
            for (int y = 0; y < img.getHeight(); y++) {
                writer.write("[");
                for (int x = 0; x < img.getWidth(); x++) {
                    Color cor;
                    cor = new Color(img.getRGB(x, y));
                    int r = cor.getRed();
                    int g = cor.getGreen();
                    int b = cor.getBlue();
                    if (r == 0 && g == 0 && b == 0) {
                        writer.write("0");
                    } else if (r == 255 && g == 255 && b == 255) {
                        writer.write("1");
                    } else if (r > g && r > b) {
                        writer.write("2");
                    } else if (g > r && g > b) {
                        writer.write("3");
                    } else if (b > r && b > g) {
                        writer.write("4");
                    }

                    if (x != img.getWidth() - 1) {
                        writer.write(",");
                    }
                }
                writer.write("]");
                if (y != img.getHeight() - 1) {
                    writer.write(",");
                    writer.write("\n");
                }
            }
            writer.write(" ];");
            writer.close();
            JOptionPane.showMessageDialog(null, "Operação concluída!", null, JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), null, JOptionPane.ERROR_MESSAGE);
        }
    }
    
}
